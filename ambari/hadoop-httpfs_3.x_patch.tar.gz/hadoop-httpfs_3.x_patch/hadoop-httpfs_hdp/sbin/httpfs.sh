#!/bin/bash

export HADOOP_HOME=${HADOOP_HOME:-/usr/hdp/2.6.5.0-292/hadoop}
export HADOOP_LIBEXEC_DIR=${HADOOP_HOME}/libexec
export CATALINA_BASE=/etc/hadoop-httpfs/tomcat-deployment
export HTTPFS_CONFIG=/etc/hadoop-httpfs/conf

exec /usr/hdp/2.6.5.0-292/hadoop-httpfs/sbin/httpfs.sh.distro "$@"
