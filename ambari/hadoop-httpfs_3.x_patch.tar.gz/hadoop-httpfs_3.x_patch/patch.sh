#!/bin/bash
\cp -a hadoop-httpfs_etc/conf/* /etc/hadoop-httpfs/conf/
\cp -a hadoop-httpfs_hdp/{logs,temp,usr,webapps} /usr/hdp/current/hadoop-httpfs/
